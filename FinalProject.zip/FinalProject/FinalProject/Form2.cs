﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Linq;

namespace FinalProject
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            LoadFromXML(@"..\..\..\calls.xml");
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void LoadFromXML(string xmlFilePath)
        {
            XDocument xmlDoc = XDocument.Load(xmlFilePath);
            int rowNum = 1;
            foreach (XElement callElement in xmlDoc.Descendants("call"))
            {
                string date = callElement.Element("date").Value;
                string time = callElement.Element("time").Value;
                string address = callElement.Element("subscriber_address").Value;
                string issue = callElement.Element("issue").Value;
                string status = callElement.Element("status").Value;

                CallsDGV.Rows.Add(rowNum, date, GetDayOfWeek(date), time, address, issue, status);
                rowNum++;
            }
        }

        private string GetDayOfWeek(string dateString)
        {
            DateTime date = DateTime.Parse(dateString);
            return date.ToString("ddd");
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string date = monthCalendar.SelectionStart.ToString("yyyy-MM-dd");
            string time = textBoxTime.Text;
            string address = textBoxAddress.Text;
            string problem = textBoxProblem.Text;
            string status = comboBoxStatus.SelectedItem.ToString();

            CallsDGV.Rows.Add(CallsDGV.Rows.Count + 1, date, GetDayOfWeek(date), time, address, problem, status);

            textBoxTime.Clear();
            textBoxAddress.Clear();
            textBoxProblem.Clear();
            comboBoxStatus.SelectedIndex = -1;
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (CallsDGV.SelectedRows.Count == 1)
            {
                string date = monthCalendar.SelectionStart.ToString("yyyy-MM-dd");
                string time = textBoxTime.Text;
                string address = textBoxAddress.Text;
                string problem = textBoxProblem.Text;
                string status = comboBoxStatus.SelectedItem?.ToString();

                if (string.IsNullOrWhiteSpace(date) || string.IsNullOrWhiteSpace(time) ||
                    string.IsNullOrWhiteSpace(address) || string.IsNullOrWhiteSpace(problem) ||
                    string.IsNullOrWhiteSpace(status))
                {
                    MessageBox.Show("Заповніть усю інформацію для редагування", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int rowIndex = CallsDGV.SelectedRows[0].Index;
                CallsDGV.Rows[rowIndex].Cells["ColumnDate"].Value = date;
                CallsDGV.Rows[rowIndex].Cells["ColumnTime"].Value = time;
                CallsDGV.Rows[rowIndex].Cells["ColumnAddress"].Value = address;
                CallsDGV.Rows[rowIndex].Cells["ColumnProblem"].Value = problem;
                CallsDGV.Rows[rowIndex].Cells["ColumnStatus"].Value = status;

                textBoxTime.Clear();
                textBoxAddress.Clear();
                textBoxProblem.Clear();
                comboBoxStatus.SelectedIndex = -1;
            }
            else
            {
                MessageBox.Show("Оберіть рядок для редагування.");
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (CallsDGV.SelectedRows.Count == 1)
            {
                int rowIndex = CallsDGV.SelectedRows[0].Index;
                CallsDGV.Rows.RemoveAt(rowIndex);
                UpdateRowNumbers();
            }
            else
            {
                MessageBox.Show("Оберіть рядок для видалення.");
            }
        }

        private void UpdateRowNumbers()
        {
            for (int i = 0; i < CallsDGV.Rows.Count; i++)
            {
                CallsDGV.Rows[i].Cells["ColumnNum"].Value = (i + 1).ToString();
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            XDocument xmlDoc = new XDocument();
            XElement callsElement = new XElement("calls");

            foreach (DataGridViewRow row in CallsDGV.Rows)
            {
                XElement callElement = new XElement("call");

                callElement.Add(new XElement("date", row.Cells["ColumnDate"].Value));
                callElement.Add(new XElement("time", row.Cells["ColumnTime"].Value));
                callElement.Add(new XElement("subscriber_address", row.Cells["ColumnAddress"].Value));
                callElement.Add(new XElement("issue", row.Cells["ColumnProblem"].Value));
                callElement.Add(new XElement("status", row.Cells["ColumnStatus"].Value));

                callsElement.Add(callElement);
            }

            xmlDoc.Add(callsElement);
            xmlDoc.Save(@"..\..\..\calls.xml");

            MessageBox.Show("Дані успішно збережені у файл calls.xml", "Збереження", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void buttonClear_Click_1(object sender, EventArgs e)
        {
            CallsDGV.Rows.Clear();
        }

        private void buttonLoad_Click_1(object sender, EventArgs e)
        {
            CallsDGV.Rows.Clear();
            LoadFromXML(@"..\..\..\calls.xml");
        }

        private void buttonPerform_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                textBoxCount.Visible = false;
                DateTime currentDate = DateTime.Today;
                DateTime threeDaysAgo = currentDate.AddDays(-2);

                CallsDGV1.Rows.Clear();

                foreach (DataGridViewRow row in CallsDGV.Rows)
                {
                    if (DateTime.TryParse(row.Cells["ColumnDate"].Value.ToString(), out DateTime date))
                    {
                        if (date >= threeDaysAgo && date <= currentDate && row.Cells["ColumnStatus"].Value.ToString() == "Ведуться роботи")
                        {
                            DataGridViewRow newRow = (DataGridViewRow)row.Clone();
                            foreach (DataGridViewCell cell in row.Cells)
                            {
                                newRow.Cells[cell.ColumnIndex].Value = cell.Value;
                            }
                            CallsDGV1.Rows.Add(newRow);
                        }
                    }
                }
            }
            else if (radioButton2.Checked)
            {
                textBoxCount.Visible = true;
                DateTime currentDate = DateTime.Today;
                DateTime firstDayOfCurrentMonth = new DateTime(currentDate.Year, currentDate.Month, 1);
                DateTime firstDayOfPreviousMonth = firstDayOfCurrentMonth.AddMonths(-1);
                DateTime lastDayOfPreviousMonth = firstDayOfCurrentMonth.AddDays(-1);

                CallsDGV1.Rows.Clear();

                foreach (DataGridViewRow row in CallsDGV.Rows)
                {
                    if (DateTime.TryParse(row.Cells["ColumnDate"].Value.ToString(), out DateTime date))
                    {
                        if (date >= firstDayOfPreviousMonth && date <= lastDayOfPreviousMonth)
                        {
                            DataGridViewRow newRow = (DataGridViewRow)row.Clone();
                            foreach (DataGridViewCell cell in row.Cells)
                            {
                                newRow.Cells[cell.ColumnIndex].Value = cell.Value;
                            }
                            CallsDGV1.Rows.Add(newRow);
                        }
                    }
                }

                textBoxCount.Text = CallsDGV1.Rows.Count.ToString();
            }
            else if (radioButton3.Checked)
            {
                textBoxCount.Visible = false;
                DateTime currentDate = DateTime.Today;
                DateTime firstDayOfCurrentYear = new DateTime(currentDate.Year, 1, 1);
                DateTime firstDayOfNextYear = firstDayOfCurrentYear.AddYears(1);

                CallsDGV1.Rows.Clear();

                DateTime[] dates = new DateTime[CallsDGV.Rows.Count];

                for (int i = 0; i < CallsDGV.Rows.Count; i++)
                {
                    DateTime.TryParse(CallsDGV.Rows[i].Cells["ColumnDate"].Value.ToString(), out dates[i]);
                }

                Array.Sort(dates);
                Array.Reverse(dates);

                int lastIndexInPreviousYear = -1;
                for (int i = 0; i < dates.Length; i++)
                {
                    if (dates[i] >= firstDayOfCurrentYear && dates[i] < firstDayOfNextYear)
                    {
                        lastIndexInPreviousYear = i;
                        break;
                    }
                }

                if (lastIndexInPreviousYear >= 0)
                {
                    DataGridViewRow newRow = new DataGridViewRow();
                    foreach (DataGridViewCell cell in CallsDGV.Rows[lastIndexInPreviousYear].Cells)
                    {
                        newRow.Cells.Add(new DataGridViewTextBoxCell { Value = cell.Value });
                    }
                    CallsDGV1.Rows.Add(newRow);
                }

                CallsDGV1.Refresh();
            }
            else if (radioButton4.Checked)
            {
                textBoxCount.Visible = false;
                string folderPath = @"..\..\..\Dates";
                Directory.CreateDirectory(folderPath);

                Dictionary<string, List<DataGridViewRow>> callsByDate = new Dictionary<string, List<DataGridViewRow>>();

                foreach (DataGridViewRow row in CallsDGV.Rows)
                {
                    if (row.IsNewRow) continue;

                    string status = row.Cells["ColumnStatus"].Value?.ToString();
                    if (status == "Ведуться роботи")
                    {
                        string date = row.Cells["ColumnDate"].Value?.ToString();
                        if (!string.IsNullOrWhiteSpace(date))
                        {
                            if (!callsByDate.ContainsKey(date))
                            {
                                callsByDate[date] = new List<DataGridViewRow>();
                            }
                            callsByDate[date].Add(row);
                        }
                    }
                }

                foreach (var date in callsByDate.Keys)
                {
                    string fileName = $"{date}.xml";
                    string filePath = Path.Combine(folderPath, fileName);

                    XElement callsElement = new XElement("calls");

                    foreach (var row in callsByDate[date])
                    {
                        XElement callElement = new XElement("call",
                            new XElement("date", row.Cells["ColumnDate"].Value),
                            new XElement("time", row.Cells["ColumnTime"].Value),
                            new XElement("subscriber_address", row.Cells["ColumnAddress"].Value),
                            new XElement("issue", row.Cells["ColumnProblem"].Value),
                            new XElement("status", row.Cells["ColumnStatus"].Value)
                        );
                        callsElement.Add(callElement);
                    }

                    if (File.Exists(filePath))
                    {
                        XDocument existingDoc = XDocument.Load(filePath);
                        existingDoc.Root.Add(callsElement.Elements());
                        existingDoc.Save(filePath);
                    }
                    else
                    {
                        XDocument newDoc = new XDocument(callsElement);
                        newDoc.Save(filePath);
                    }
                }

                MessageBox.Show("XML-файли були успішно створені або оновлені у папці Dates", "Успіх", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Оберіть фільтр для виконання операції.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace FinalProject
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            LoadFromXML(@"..\..\..\calls.xml");
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {

            Application.Exit();

        }

        private void LoadFromXML(string xmlFilePath)
        {
            // завантажуємо XML-файл
            XDocument xmlDoc = XDocument.Load(xmlFilePath);

            // Читаємо кожен елемент <call> з XML і додаємо його у DataGridView
            int rowNum = 1;
            foreach (XElement callElement in xmlDoc.Descendants("call"))
            {
                string date = callElement.Element("date").Value;
                string time = callElement.Element("time").Value;
                string address = callElement.Element("subscriber_address").Value;
                string issue = callElement.Element("issue").Value;
                string status = callElement.Element("status").Value;

                // додаємо рядок у DataGridView
                CallsDGV.Rows.Add(rowNum, date, GetDayOfWeek(date), time, address, issue, status);
                rowNum++;
            }
        }

        private string GetDayOfWeek(string dateString)
        {
            DateTime date = DateTime.Parse(dateString);
            return date.ToString("ddd");
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            // отримуємо значення з елементів форми
            string date = monthCalendar.SelectionStart.ToString("yyyy-MM-dd");
            string time = textBoxTime.Text;
            string address = textBoxAddress.Text;
            string problem = textBoxProblem.Text;
            string status = comboBoxStatus.SelectedItem.ToString();

            // додаємо рядок у CallsDGV
            CallsDGV.Rows.Add(CallsDGV.Rows.Count + 1, date, GetDayOfWeek(date), time, address, problem, status);

            // очищуємо поля введення після додавання рядка
            textBoxTime.Clear();
            textBoxAddress.Clear();
            textBoxProblem.Clear();
            comboBoxStatus.SelectedIndex = -1; // Скидання вибору в ComboBox
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            // перевірка, чи вибрано рядок для редагування
            if (CallsDGV.SelectedRows.Count == 1)
            {
                // Отримання даних з елементів форми
                string date = monthCalendar.SelectionStart.ToString("yyyy-MM-dd");
                string time = textBoxTime.Text;
                string address = textBoxAddress.Text;
                string problem = textBoxProblem.Text;
                string status = comboBoxStatus.SelectedItem?.ToString();

                // перевірка, чи всі поля заповнені
                if (string.IsNullOrWhiteSpace(date) || string.IsNullOrWhiteSpace(time) ||
                    string.IsNullOrWhiteSpace(address) || string.IsNullOrWhiteSpace(problem) ||
                    string.IsNullOrWhiteSpace(status))
                {
                    MessageBox.Show("Заповніть усю інформацію для редагування", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // Перериваємо виконання методу, якщо не всі поля заповнені
                }

                // отримуємо індекс вибраного рядка
                int rowIndex = CallsDGV.SelectedRows[0].Index;

                // Оновлюємо дані в вибраному рядку
                CallsDGV.Rows[rowIndex].Cells["ColumnDate"].Value = date;
                CallsDGV.Rows[rowIndex].Cells["ColumnTime"].Value = time;
                CallsDGV.Rows[rowIndex].Cells["ColumnAddress"].Value = address;
                CallsDGV.Rows[rowIndex].Cells["ColumnProblem"].Value = problem;
                CallsDGV.Rows[rowIndex].Cells["ColumnStatus"].Value = status;

                // очищуємо поля введення після оновлення рядка
                textBoxTime.Clear();
                textBoxAddress.Clear();
                textBoxProblem.Clear();
                comboBoxStatus.SelectedIndex = -1; // Скидання вибору в ComboBox
            }
            else
            {
                MessageBox.Show("Оберіть рядок для редагування.");
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            // перевірка, чи вибрано рядок для видалення
            if (CallsDGV.SelectedRows.Count == 1)
            {
                // отримуємо індекс вибраного рядка
                int rowIndex = CallsDGV.SelectedRows[0].Index;

                // видаляємо вибраний рядок з таблиці
                CallsDGV.Rows.RemoveAt(rowIndex);

                // оновлюємо номери рядків після видалення
                UpdateRowNumbers();
            }
            else
            {
                MessageBox.Show("Оберіть рядок для видалення.");
            }
        }

        private void UpdateRowNumbers()
        {
            // Оновлюємо номери рядків у стовпці "ColumnNum"
            for (int i = 0; i < CallsDGV.Rows.Count; i++)
            {
                CallsDGV.Rows[i].Cells["ColumnNum"].Value = (i + 1).ToString();
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            // Створюємо новий XML-документ
            XDocument xmlDoc = new XDocument();
            // Створюємо кореневий елемент
            XElement callsElement = new XElement("calls");

            // Додаємо дані з DataGridView до XML-структури
            foreach (DataGridViewRow row in CallsDGV.Rows)
            {
                // Створюємо елемент <call> для кожного рядка
                XElement callElement = new XElement("call");

                // Додаємо дані з кожної комірки рядка у відповідні елементи
                callElement.Add(new XElement("date", row.Cells["ColumnDate"].Value));
                callElement.Add(new XElement("time", row.Cells["ColumnTime"].Value));
                callElement.Add(new XElement("subscriber_address", row.Cells["ColumnAddress"].Value));
                callElement.Add(new XElement("issue", row.Cells["ColumnProblem"].Value));
                callElement.Add(new XElement("status", row.Cells["ColumnStatus"].Value));

                // Додаємо елемент <call> до кореневого елемента <calls>
                callsElement.Add(callElement);
            }

            // Додаємо кореневий елемент до XML-документу
            xmlDoc.Add(callsElement);

            // Зберігаємо XML-документ у файл calls.xml
            xmlDoc.Save(@"..\..\..\calls.xml");

            MessageBox.Show("Дані успішно збережені у файл calls.xml", "Збереження", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }



        private void buttonClear_Click_1(object sender, EventArgs e)
        {
            CallsDGV.Rows.Clear();
        }

        private void buttonLoad_Click_1(object sender, EventArgs e)
        {
            CallsDGV.Rows.Clear();
            LoadFromXML(@"..\..\..\calls.xml");
        }


        private void buttonSort_Click(object sender, EventArgs e)
        {
            // Отримуємо дані з таблиці
            var data = GetDataFromDGV();

            // Сортуємо дані за датою та часом
            data = QuickSort(data);

            // Оновлюємо номери звінків
            for (int i = 0; i < data.Length; i++)
            {
                data[i].Item2.Cells["ColumnNum"].Value = i + 1;
            }

            // Встановлюємо відсортовані дані в таблицю
            SetDataToDGV(data);
        }


        // Метод для отримання даних з таблиці
        private Tuple<DateTime, DataGridViewRow>[] GetDataFromDGV()
        {
            var data = new List<Tuple<DateTime, DataGridViewRow>>();

            foreach (DataGridViewRow row in CallsDGV.Rows)
            {
                if (!row.IsNewRow)
                {
                    var dateStr = row.Cells["ColumnDate"].Value?.ToString();
                    var timeStr = row.Cells["ColumnTime"].Value?.ToString();
                    if (DateTime.TryParse($"{dateStr} {timeStr}", out DateTime dateTime))
                    {
                        data.Add(Tuple.Create(dateTime, row));
                    }
                }
            }

            return data.ToArray();
        }

        // Метод для встановлення даних в таблицю
        private void SetDataToDGV(Tuple<DateTime, DataGridViewRow>[] data)
        {
            CallsDGV.Rows.Clear();

            foreach (var item in data)
            {
                CallsDGV.Rows.Add(item.Item2);
            }
        }

        // Метод для обміну значень
        static void Swap(ref Tuple<DateTime, DataGridViewRow> x, ref Tuple<DateTime, DataGridViewRow> y)
        {
            var t = x;
            x = y;
            y = t;
        }

        // Метод повертає індекс опорного елементу
        static int Partition(Tuple<DateTime, DataGridViewRow>[] array, int minIndex, int maxIndex)
        {
            var pivot = minIndex - 1;
            for (var i = minIndex; i < maxIndex; i++)
            {
                if (array[i].Item1 < array[maxIndex].Item1)
                {
                    pivot++;
                    Swap(ref array[pivot], ref array[i]);
                }
            }

            pivot++;
            Swap(ref array[pivot], ref array[maxIndex]);
            return pivot;
        }

        // Швидке сортування
        static Tuple<DateTime, DataGridViewRow>[] QuickSort(Tuple<DateTime, DataGridViewRow>[] array, int minIndex, int maxIndex)
        {
            if (minIndex >= maxIndex)
            {
                return array;
            }

            var pivotIndex = Partition(array, minIndex, maxIndex);
            QuickSort(array, minIndex, pivotIndex - 1);
            QuickSort(array, pivotIndex + 1, maxIndex);

            return array;
        }

        static Tuple<DateTime, DataGridViewRow>[] QuickSort(Tuple<DateTime, DataGridViewRow>[] array)
        {
            return QuickSort(array, 0, array.Length - 1);
        }

        private int BinarySearch(Tuple<DateTime, DataGridViewRow>[] array, DateTime targetDate)
        {
            int left = 0;
            int right = array.Length - 1;

            while (left <= right)
            {
                int mid = (left + right) / 2;
                DateTime midDate = array[mid].Item1.Date; // Отримуємо тільки дату без часу
                if (midDate == targetDate.Date) // Порівнюємо тільки дати
                {
                    return mid;
                }
                else if (midDate < targetDate.Date)
                {
                    left = mid + 1;
                }
                else
                {
                    right = mid - 1;
                }
            }

            return -1; // елемент не знайдено
        }


        private void buttonSearch_Click(object sender, EventArgs e)
        {
            // Отримуємо дату з текстового поля
            if (DateTime.TryParse(textBoxSearchDate.Text, out DateTime searchDate))
            {
                // Отримуємо дані з таблиці
                var data = GetDataFromDGV();

                // Перевіряємо, чи масив не порожній
                if (data.Length == 0)
                {
                    MessageBox.Show("Таблиця порожня. Немає даних для пошуку.");
                    return;
                }

                // Сортуємо дані за датою та часом
                data = QuickSort(data);

                // Виконуємо бінарний пошук
                int index = BinarySearch(data, searchDate);

                if (index != -1)
                {
                    // Виділяємо знайдений рядок
                    CallsDGV.ClearSelection();
                    CallsDGV.Rows[data[index].Item2.Index].Selected = true;
                    CallsDGV.FirstDisplayedScrollingRowIndex = data[index].Item2.Index;
                }
                else
                {
                    MessageBox.Show("Заявку з вказаною датою не знайдено.");
                }
            }
            else
            {
                MessageBox.Show("Некоректний формат дати. Введіть дату у форматі yyyy-MM-dd.");
            }
        }

        private void buttonPerform_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                textBoxCount.Visible = false;
                // Отримуємо поточну дату
                DateTime currentDate = DateTime.Today;

                // Отримуємо дату 3 дні тому
                DateTime threeDaysAgo = currentDate.AddDays(-2);

                // Очищаємо таблицю CallsDGV1 перед відображенням нових даних
                CallsDGV1.Rows.Clear();

                // Перевіряємо кожен рядок у таблиці CallsDGV
                foreach (DataGridViewRow row in CallsDGV.Rows)
                {
                    // Отримуємо дату з рядка
                    if (DateTime.TryParse(row.Cells["ColumnDate"].Value.ToString(), out DateTime date))
                    {
                        // Перевіряємо, чи дата рядка входить у діапазон останніх 3 днів
                        if (date >= threeDaysAgo && date <= currentDate)
                        {
                            // Перевіряємо, чи статус заявки "Ведуться роботи"
                            if (row.Cells["ColumnStatus"].Value.ToString() == "Ведуться роботи")
                            {
                                // Додаємо рядок у CallsDGV1
                                DataGridViewRow newRow = (DataGridViewRow)row.Clone();
                                foreach (DataGridViewCell cell in row.Cells)
                                {
                                    newRow.Cells[cell.ColumnIndex].Value = cell.Value;
                                }
                                CallsDGV1.Rows.Add(newRow);
                            }
                        }
                    }
                }
            }
            else if (radioButton2.Checked)
            {
                textBoxCount.Visible = true;
                // Отримуємо поточну дату
                DateTime currentDate = DateTime.Today;

                // Отримуємо перший день поточного місяця
                DateTime firstDayOfCurrentMonth = new DateTime(currentDate.Year, currentDate.Month, 1);

                // Отримуємо перший день попереднього місяця
                DateTime firstDayOfPreviousMonth = firstDayOfCurrentMonth.AddMonths(-1);

                // Отримуємо останній день попереднього місяця
                DateTime lastDayOfPreviousMonth = firstDayOfCurrentMonth.AddDays(-1);

                // Очищаємо таблицю CallsDGV1 перед виведенням нових даних
                CallsDGV1.Rows.Clear();

                // Перевіряємо кожен рядок у таблиці CallsDGV
                foreach (DataGridViewRow row in CallsDGV.Rows)
                {
                    // Отримуємо дату з рядка
                    if (DateTime.TryParse(row.Cells["ColumnDate"].Value.ToString(), out DateTime date))
                    {
                        // Перевіряємо, чи дата рядка належить попередньому місяцю
                        if (date >= firstDayOfPreviousMonth && date <= lastDayOfPreviousMonth)
                        {
                            // Додаємо рядок у CallsDGV1
                            DataGridViewRow newRow = (DataGridViewRow)row.Clone();
                            foreach (DataGridViewCell cell in row.Cells)
                            {
                                newRow.Cells[cell.ColumnIndex].Value = cell.Value;
                            }
                            CallsDGV1.Rows.Add(newRow);
                        }
                    }
                }

                textBoxCount.Text = CallsDGV1.Rows.Count.ToString();
            }
            else if (radioButton3.Checked)
            {
                textBoxCount.Visible = false;
                // отримуємо поточну дату
                DateTime currentDate = DateTime.Today;

                // Отримуємо перший день поточного року
                DateTime firstDayOfCurrentYear = new DateTime(currentDate.Year, 1, 1);

                // Отримуємо перший день наступного року
                DateTime firstDayOfNextYear = firstDayOfCurrentYear.AddYears(1);

                CallsDGV1.Rows.Clear();

                // Створюємо масив для зберігання дат
                DateTime[] dates = new DateTime[CallsDGV.Rows.Count];

                // Заповнюємо масив датами з CallsDGV
                for (int i = 0; i < CallsDGV.Rows.Count; i++)
                {
                    DateTime.TryParse(CallsDGV.Rows[i].Cells["ColumnDate"].Value.ToString(), out dates[i]);
                }

                // Сортуємо масив дат у зворотньому порядку
                Array.Sort(dates);
                Array.Reverse(dates);

                // знаходимо індекс останньої дати
                int lastIndexInPreviousYear = -1;
                for (int i = 0; i < dates.Length; i++)
                {
                    if (dates[i] >= firstDayOfCurrentYear && dates[i] < firstDayOfNextYear)
                    {
                        lastIndexInPreviousYear = i;
                        break;
                    }
                }

                // Виводимо останню заявку з минулого року у CallsDGV1
                if (lastIndexInPreviousYear >= 0)
                {
                    DataGridViewRow newRow = new DataGridViewRow();
                    foreach (DataGridViewCell cell in CallsDGV.Rows[lastIndexInPreviousYear].Cells)
                    {
                        newRow.Cells.Add(new DataGridViewTextBoxCell { Value = cell.Value });
                    }
                    CallsDGV1.Rows.Add(newRow);
                }

                CallsDGV1.Refresh();
            }
            else if (radioButton4.Checked)
            {
                textBoxCount.Visible = false;
                // Створюємо папку Dates, якщо вона ще не існує
                string folderPath = @"..\..\..\Dates";
                Directory.CreateDirectory(folderPath);

                // словник для зберігання заявок за датами
                Dictionary<string, List<DataGridViewRow>> callsByDate = new Dictionary<string, List<DataGridViewRow>>();

                // проходимо по кожному рядку в CallsDGV
                foreach (DataGridViewRow row in CallsDGV.Rows)
                {
                    if (row.IsNewRow) continue; // Пропустити новий рядок

                    string status = row.Cells["ColumnStatus"].Value?.ToString();
                    if (status == "Ведуться роботи")
                    {
                        string date = row.Cells["ColumnDate"].Value?.ToString();
                        if (!string.IsNullOrWhiteSpace(date))
                        {
                            if (!callsByDate.ContainsKey(date))
                            {
                                callsByDate[date] = new List<DataGridViewRow>();
                            }
                            callsByDate[date].Add(row);
                        }
                    }
                }

                // створюємо або оновлюємо XML-файли для кожної дати
                foreach (var date in callsByDate.Keys)
                {
                    string fileName = $"{date}.xml";
                    string filePath = Path.Combine(folderPath, fileName);

                    // створюємо кореневий елемент для нових заявок
                    XElement callsElement = new XElement("calls");

                    // додаємо заявки до нового XML-документу
                    foreach (var row in callsByDate[date])
                    {
                        XElement callElement = new XElement("call",
                            new XElement("date", row.Cells["ColumnDate"].Value),
                            new XElement("time", row.Cells["ColumnTime"].Value),
                            new XElement("subscriber_address", row.Cells["ColumnAddress"].Value),
                            new XElement("issue", row.Cells["ColumnProblem"].Value),
                            new XElement("status", row.Cells["ColumnStatus"].Value)
                        );
                        callsElement.Add(callElement);
                    }

                    // якщо файл вже існує, завантажуємо його та додаємо нові заявки
                    if (File.Exists(filePath))
                    {
                        XDocument existingDoc = XDocument.Load(filePath);
                        existingDoc.Root.Add(callsElement.Elements());
                        existingDoc.Save(filePath);
                    }
                    else
                    {
                        // створюємо новий XML-документ
                        XDocument newDoc = new XDocument(callsElement);
                        newDoc.Save(filePath);
                    }
                }

                MessageBox.Show("XML-файли були успішно створені або оновлені у папці Dates", "Успіх", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Оберіть фільтр для виконання операції.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace FinalProject
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            LoadFromXML(@"..\..\..\calls.xml");
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {

            Application.Exit();

        }

        private void LoadFromXML(string xmlFilePath)
        {
            // Завантажуємо XML-файл
            XDocument xmlDoc = XDocument.Load(xmlFilePath);

            // Читаємо кожен елемент <call> з XML і додаємо його у DataGridView
            int rowNum = 1;
            foreach (XElement callElement in xmlDoc.Descendants("call"))
            {
                string date = callElement.Element("date").Value;
                string time = callElement.Element("time").Value;
                string address = callElement.Element("subscriber_address").Value;
                string issue = callElement.Element("issue").Value;
                string status = callElement.Element("status").Value;

                // Додаємо рядок у DataGridView
                CallsDGV.Rows.Add(rowNum, date, GetDayOfWeek(date), time, address, issue, status);
                rowNum++;
            }
        }

        private string GetDayOfWeek(string dateString)
        {
            DateTime date = DateTime.Parse(dateString);
            return date.ToString("ddd");
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            // Отримуємо значення з елементів форми
            string date = monthCalendar.SelectionStart.ToString("yyyy-MM-dd");
            string time = textBoxTime.Text;
            string address = textBoxAddress.Text;
            string problem = textBoxProblem.Text;
            string status = comboBoxStatus.SelectedItem.ToString();

            // Додаємо рядок у CallsDGV
            CallsDGV.Rows.Add(CallsDGV.Rows.Count + 1, date, GetDayOfWeek(date), time, address, problem, status);

            // Очищуємо поля введення після додавання рядка
            textBoxTime.Clear();
            textBoxAddress.Clear();
            textBoxProblem.Clear();
            comboBoxStatus.SelectedIndex = -1; // Скидання вибору в ComboBox
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            // Перевірка, чи вибрано рядок для редагування
            if (CallsDGV.SelectedRows.Count == 1)
            {
                // Отримання даних з елементів форми
                string date = monthCalendar.SelectionStart.ToString("yyyy-MM-dd");
                string time = textBoxTime.Text;
                string address = textBoxAddress.Text;
                string problem = textBoxProblem.Text;
                string status = comboBoxStatus.SelectedItem?.ToString();

                // Перевірка, чи всі поля заповнені
                if (string.IsNullOrWhiteSpace(date) || string.IsNullOrWhiteSpace(time) ||
                    string.IsNullOrWhiteSpace(address) || string.IsNullOrWhiteSpace(problem) ||
                    string.IsNullOrWhiteSpace(status))
                {
                    MessageBox.Show("Заповніть усю інформацію для редагування", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // Перериваємо виконання методу, якщо не всі поля заповнені
                }

                // Отримуємо індекс вибраного рядка
                int rowIndex = CallsDGV.SelectedRows[0].Index;

                // Оновлюємо дані в вибраному рядку
                CallsDGV.Rows[rowIndex].Cells["ColumnDate"].Value = date;
                CallsDGV.Rows[rowIndex].Cells["ColumnTime"].Value = time;
                CallsDGV.Rows[rowIndex].Cells["ColumnAddress"].Value = address;
                CallsDGV.Rows[rowIndex].Cells["ColumnProblem"].Value = problem;
                CallsDGV.Rows[rowIndex].Cells["ColumnStatus"].Value = status;

                // Очищуємо поля введення після оновлення рядка
                textBoxTime.Clear();
                textBoxAddress.Clear();
                textBoxProblem.Clear();
                comboBoxStatus.SelectedIndex = -1; // Скидання вибору в ComboBox
            }
            else
            {
                MessageBox.Show("Оберіть рядок для редагування.");
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            // Перевірка, чи вибрано рядок для видалення
            if (CallsDGV.SelectedRows.Count == 1)
            {
                // Отримуємо індекс вибраного рядка
                int rowIndex = CallsDGV.SelectedRows[0].Index;

                // Видаляємо вибраний рядок з таблиці
                CallsDGV.Rows.RemoveAt(rowIndex);

                // Оновлюємо номери рядків після видалення
                UpdateRowNumbers();
            }
            else
            {
                MessageBox.Show("Оберіть рядок для видалення.");
            }
        }

        private void UpdateRowNumbers()
        {
            // Оновлюємо номери рядків у стовпці "ColumnNum"
            for (int i = 0; i < CallsDGV.Rows.Count; i++)
            {
                CallsDGV.Rows[i].Cells["ColumnNum"].Value = (i + 1).ToString();
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            // Створюємо новий XML-документ
            XDocument xmlDoc = new XDocument();
            // Створюємо кореневий елемент
            XElement callsElement = new XElement("calls");

            // Додаємо дані з DataGridView до XML-структури
            foreach (DataGridViewRow row in CallsDGV.Rows)
            {
                // Створюємо елемент <call> для кожного рядка
                XElement callElement = new XElement("call");

                // Додаємо дані з кожної комірки рядка у відповідні елементи
                callElement.Add(new XElement("date", row.Cells["ColumnDate"].Value));
                callElement.Add(new XElement("time", row.Cells["ColumnTime"].Value));
                callElement.Add(new XElement("subscriber_address", row.Cells["ColumnAddress"].Value));
                callElement.Add(new XElement("issue", row.Cells["ColumnProblem"].Value));
                callElement.Add(new XElement("status", row.Cells["ColumnStatus"].Value));

                // Додаємо елемент <call> до кореневого елемента <calls>
                callsElement.Add(callElement);
            }

            // Додаємо кореневий елемент до XML-документу
            xmlDoc.Add(callsElement);

            // Зберігаємо XML-документ у файл calls.xml
            xmlDoc.Save(@"..\..\..\calls.xml");

            MessageBox.Show("Дані успішно збережені у файл calls.xml", "Збереження", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }



        private void buttonClear_Click_1(object sender, EventArgs e)
        {
            CallsDGV.Rows.Clear();
        }

        private void buttonLoad_Click_1(object sender, EventArgs e)
        {
            CallsDGV.Rows.Clear();
            LoadFromXML(@"..\..\..\calls.xml");
        }

        private void buttonPerform_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                textBoxCount.Visible = false;
                // Отримуємо поточну дату
                DateTime currentDate = DateTime.Today;

                // Отримуємо дату 3 дні тому
                DateTime threeDaysAgo = currentDate.AddDays(-2);

                // Очищаємо таблицю CallsDGV1 перед відображенням нових даних
                CallsDGV1.Rows.Clear();

                // Перевіряємо кожен рядок у таблиці CallsDGV
                foreach (DataGridViewRow row in CallsDGV.Rows)
                {
                    // Отримуємо дату з рядка
                    if (DateTime.TryParse(row.Cells["ColumnDate"].Value.ToString(), out DateTime date))
                    {
                        // Перевіряємо, чи дата рядка входить у діапазон останніх 3 днів
                        if (date >= threeDaysAgo && date <= currentDate)
                        {
                            // Перевіряємо, чи статус заявки "Ведуться роботи"
                            if (row.Cells["ColumnStatus"].Value.ToString() == "Ведуться роботи")
                            {
                                // Додаємо рядок у CallsDGV1
                                DataGridViewRow newRow = (DataGridViewRow)row.Clone();
                                foreach (DataGridViewCell cell in row.Cells)
                                {
                                    newRow.Cells[cell.ColumnIndex].Value = cell.Value;
                                }
                                CallsDGV1.Rows.Add(newRow);
                            }
                        }
                    }
                }
            }
            else if (radioButton2.Checked)
            {
                textBoxCount.Visible = true;
                // Отримуємо поточну дату
                DateTime currentDate = DateTime.Today;

                // Отримуємо перший день поточного місяця
                DateTime firstDayOfCurrentMonth = new DateTime(currentDate.Year, currentDate.Month, 1);

                // Отримуємо перший день попереднього місяця
                DateTime firstDayOfPreviousMonth = firstDayOfCurrentMonth.AddMonths(-1);

                // Отримуємо останній день попереднього місяця
                DateTime lastDayOfPreviousMonth = firstDayOfCurrentMonth.AddDays(-1);

                // Очищаємо таблицю CallsDGV1 перед виведенням нових даних
                CallsDGV1.Rows.Clear();

                // Перевіряємо кожен рядок у таблиці CallsDGV
                foreach (DataGridViewRow row in CallsDGV.Rows)
                {
                    // Отримуємо дату з рядка
                    if (DateTime.TryParse(row.Cells["ColumnDate"].Value.ToString(), out DateTime date))
                    {
                        // Перевіряємо, чи дата рядка належить попередньому місяцю
                        if (date >= firstDayOfPreviousMonth && date <= lastDayOfPreviousMonth)
                        {
                            // Додаємо рядок у CallsDGV1
                            DataGridViewRow newRow = (DataGridViewRow)row.Clone();
                            foreach (DataGridViewCell cell in row.Cells)
                            {
                                newRow.Cells[cell.ColumnIndex].Value = cell.Value;
                            }
                            CallsDGV1.Rows.Add(newRow);
                        }
                    }
                }

                textBoxCount.Text = CallsDGV1.Rows.Count.ToString();
            }
            else if (radioButton3.Checked)
            {
                // Отримуємо поточну дату
                DateTime currentDate = DateTime.Today;

                // Отримуємо перший день поточного року
                DateTime firstDayOfCurrentYear = new DateTime(currentDate.Year, 1, 1);

                // Отримуємо перший день наступного року
                DateTime firstDayOfNextYear = firstDayOfCurrentYear.AddYears(1);

                // Очищаємо таблицю CallsDGV1 перед виведенням нових даних
                CallsDGV1.Rows.Clear();

                // Створюємо масив для зберігання дат
                DateTime[] dates = new DateTime[CallsDGV.Rows.Count];

                // Заповнюємо масив датами з CallsDGV
                for (int i = 0; i < CallsDGV.Rows.Count; i++)
                {
                    DateTime.TryParse(CallsDGV.Rows[i].Cells["ColumnDate"].Value.ToString(), out dates[i]);
                }

                // Сортуємо масив дат у зворотньому порядку
                Array.Sort(dates);
                Array.Reverse(dates);

                // Знаходимо індекс останньої дати, яка входить у минулий рік
                int lastIndexInPreviousYear = -1;
                for (int i = 0; i < dates.Length; i++)
                {
                    if (dates[i] >= firstDayOfCurrentYear && dates[i] < firstDayOfNextYear)
                    {
                        lastIndexInPreviousYear = i;
                        break;
                    }
                }

                // Виводимо останню заявку з минулого року у CallsDGV1
                if (lastIndexInPreviousYear >= 0)
                {
                    DataGridViewRow newRow = new DataGridViewRow();
                    foreach (DataGridViewCell cell in CallsDGV.Rows[lastIndexInPreviousYear].Cells)
                    {
                        newRow.Cells.Add(new DataGridViewTextBoxCell { Value = cell.Value });
                    }
                    CallsDGV1.Rows.Add(newRow);
                }

                CallsDGV1.Refresh();
            }
            else
            {
                MessageBox.Show("Оберіть фільтр для виконання операції.");
            }
        }




    }
}

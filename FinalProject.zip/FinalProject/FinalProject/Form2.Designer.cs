﻿namespace FinalProject
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            buttonLoad = new Button();
            buttonClear = new Button();
            buttonSave = new Button();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            buttonDelete = new Button();
            buttonEdit = new Button();
            buttonAdd = new Button();
            comboBoxStatus = new ComboBox();
            textBoxProblem = new TextBox();
            textBoxAddress = new TextBox();
            textBoxTime = new TextBox();
            label2 = new Label();
            label1 = new Label();
            monthCalendar = new MonthCalendar();
            CallsDGV = new DataGridView();
            ColumnNum = new DataGridViewTextBoxColumn();
            ColumnDate = new DataGridViewTextBoxColumn();
            ColumnDay = new DataGridViewTextBoxColumn();
            ColumnTime = new DataGridViewTextBoxColumn();
            ColumnAddress = new DataGridViewTextBoxColumn();
            ColumnProblem = new DataGridViewTextBoxColumn();
            ColumnStatus = new DataGridViewTextBoxColumn();
            tabPage2 = new TabPage();
            textBoxCount = new TextBox();
            buttonPerform = new Button();
            radioButton4 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            CallsDGV1 = new DataGridView();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn6 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn7 = new DataGridViewTextBoxColumn();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)CallsDGV).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)CallsDGV1).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1265, 689);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = SystemColors.GradientInactiveCaption;
            tabPage1.Controls.Add(buttonLoad);
            tabPage1.Controls.Add(buttonClear);
            tabPage1.Controls.Add(buttonSave);
            tabPage1.Controls.Add(label7);
            tabPage1.Controls.Add(label6);
            tabPage1.Controls.Add(label5);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(buttonDelete);
            tabPage1.Controls.Add(buttonEdit);
            tabPage1.Controls.Add(buttonAdd);
            tabPage1.Controls.Add(comboBoxStatus);
            tabPage1.Controls.Add(textBoxProblem);
            tabPage1.Controls.Add(textBoxAddress);
            tabPage1.Controls.Add(textBoxTime);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(monthCalendar);
            tabPage1.Controls.Add(CallsDGV);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1257, 656);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Головна сторінка";
            // 
            // buttonLoad
            // 
            buttonLoad.Location = new Point(847, 236);
            buttonLoad.Name = "buttonLoad";
            buttonLoad.Size = new Size(253, 44);
            buttonLoad.TabIndex = 17;
            buttonLoad.Text = "Завантажити з XML";
            buttonLoad.UseVisualStyleBackColor = true;
            buttonLoad.Click += buttonLoad_Click_1;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(848, 169);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(252, 44);
            buttonClear.TabIndex = 16;
            buttonClear.Text = "Очистити";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click_1;
            // 
            // buttonSave
            // 
            buttonSave.Location = new Point(847, 96);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(253, 44);
            buttonSave.TabIndex = 15;
            buttonSave.Text = "Зберегти в XML";
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(890, 55);
            label7.Name = "label7";
            label7.Size = new Size(164, 20);
            label7.TabIndex = 14;
            label7.Text = "Взаємодія з таблицею";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(509, 145);
            label6.Name = "label6";
            label6.Size = new Size(92, 20);
            label6.TabIndex = 13;
            label6.Text = "Стан заявки";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(243, 145);
            label5.Name = "label5";
            label5.Size = new Size(162, 20);
            label5.TabIndex = 12;
            label5.Text = "Харктер несправності";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(395, 55);
            label4.Name = "label4";
            label4.Size = new Size(129, 20);
            label4.TabIndex = 11;
            label4.Text = "Адреса абонента";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(243, 55);
            label3.Name = "label3";
            label3.Size = new Size(89, 20);
            label3.TabIndex = 10;
            label3.Text = "Час дзвінка";
            // 
            // buttonDelete
            // 
            buttonDelete.Location = new Point(527, 247);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(133, 29);
            buttonDelete.TabIndex = 9;
            buttonDelete.Text = "Видалити";
            buttonDelete.UseVisualStyleBackColor = true;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // buttonEdit
            // 
            buttonEdit.Location = new Point(388, 247);
            buttonEdit.Name = "buttonEdit";
            buttonEdit.Size = new Size(133, 29);
            buttonEdit.TabIndex = 8;
            buttonEdit.Text = "Редагувати";
            buttonEdit.UseVisualStyleBackColor = true;
            buttonEdit.Click += buttonEdit_Click;
            // 
            // buttonAdd
            // 
            buttonAdd.Location = new Point(243, 247);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(133, 29);
            buttonAdd.TabIndex = 7;
            buttonAdd.Text = "Додати";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // comboBoxStatus
            // 
            comboBoxStatus.FormattingEnabled = true;
            comboBoxStatus.Items.AddRange(new object[] { "Ведуться роботи", "Усунено" });
            comboBoxStatus.Location = new Point(509, 168);
            comboBoxStatus.Name = "comboBoxStatus";
            comboBoxStatus.Size = new Size(151, 28);
            comboBoxStatus.TabIndex = 6;
            // 
            // textBoxProblem
            // 
            textBoxProblem.Location = new Point(243, 169);
            textBoxProblem.Name = "textBoxProblem";
            textBoxProblem.Size = new Size(240, 27);
            textBoxProblem.TabIndex = 5;
            // 
            // textBoxAddress
            // 
            textBoxAddress.Location = new Point(395, 84);
            textBoxAddress.Name = "textBoxAddress";
            textBoxAddress.Size = new Size(265, 27);
            textBoxAddress.TabIndex = 4;
            // 
            // textBoxTime
            // 
            textBoxTime.Location = new Point(243, 84);
            textBoxTime.Name = "textBoxTime";
            textBoxTime.Size = new Size(127, 27);
            textBoxTime.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(14, 55);
            label2.Name = "label2";
            label2.Size = new Size(96, 20);
            label2.TabIndex = 3;
            label2.Text = "Дата дзвінка";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 13);
            label1.Name = "label1";
            label1.Size = new Size(299, 20);
            label1.TabIndex = 2;
            label1.Text = "Технічна підтримка інтернет-провайдера\r\n";
            // 
            // monthCalendar
            // 
            monthCalendar.Location = new Point(14, 84);
            monthCalendar.Name = "monthCalendar";
            monthCalendar.TabIndex = 1;
            // 
            // CallsDGV
            // 
            CallsDGV.AllowUserToAddRows = false;
            CallsDGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            CallsDGV.Columns.AddRange(new DataGridViewColumn[] { ColumnNum, ColumnDate, ColumnDay, ColumnTime, ColumnAddress, ColumnProblem, ColumnStatus });
            CallsDGV.Location = new Point(14, 303);
            CallsDGV.Name = "CallsDGV";
            CallsDGV.RowHeadersWidth = 51;
            CallsDGV.Size = new Size(1240, 346);
            CallsDGV.TabIndex = 0;
            // 
            // ColumnNum
            // 
            ColumnNum.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            ColumnNum.HeaderText = "#";
            ColumnNum.MinimumWidth = 6;
            ColumnNum.Name = "ColumnNum";
            ColumnNum.Width = 50;
            // 
            // ColumnDate
            // 
            ColumnDate.FillWeight = 48.3871F;
            ColumnDate.HeaderText = "Дата дзвінка";
            ColumnDate.MinimumWidth = 6;
            ColumnDate.Name = "ColumnDate";
            ColumnDate.Width = 120;
            // 
            // ColumnDay
            // 
            ColumnDay.HeaderText = "День неділі";
            ColumnDay.MinimumWidth = 6;
            ColumnDay.Name = "ColumnDay";
            ColumnDay.Width = 75;
            // 
            // ColumnTime
            // 
            ColumnTime.FillWeight = 306.4516F;
            ColumnTime.HeaderText = "Час дзвінка";
            ColumnTime.MinimumWidth = 6;
            ColumnTime.Name = "ColumnTime";
            ColumnTime.Width = 125;
            // 
            // ColumnAddress
            // 
            ColumnAddress.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnAddress.FillWeight = 48.3871F;
            ColumnAddress.HeaderText = "Адреса абонента";
            ColumnAddress.MinimumWidth = 6;
            ColumnAddress.Name = "ColumnAddress";
            // 
            // ColumnProblem
            // 
            ColumnProblem.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnProblem.FillWeight = 48.3871F;
            ColumnProblem.HeaderText = "Характер несправності";
            ColumnProblem.MinimumWidth = 6;
            ColumnProblem.Name = "ColumnProblem";
            // 
            // ColumnStatus
            // 
            ColumnStatus.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnStatus.FillWeight = 48.3871F;
            ColumnStatus.HeaderText = "Стан заявки";
            ColumnStatus.MinimumWidth = 6;
            ColumnStatus.Name = "ColumnStatus";
            // 
            // tabPage2
            // 
            tabPage2.BackColor = SystemColors.GradientInactiveCaption;
            tabPage2.Controls.Add(textBoxCount);
            tabPage2.Controls.Add(buttonPerform);
            tabPage2.Controls.Add(radioButton4);
            tabPage2.Controls.Add(radioButton3);
            tabPage2.Controls.Add(radioButton2);
            tabPage2.Controls.Add(radioButton1);
            tabPage2.Controls.Add(CallsDGV1);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1257, 656);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Робота з заявками";
            // 
            // textBoxCount
            // 
            textBoxCount.Location = new Point(200, 248);
            textBoxCount.Name = "textBoxCount";
            textBoxCount.Size = new Size(125, 27);
            textBoxCount.TabIndex = 7;
            textBoxCount.Visible = false;
            // 
            // buttonPerform
            // 
            buttonPerform.Location = new Point(20, 248);
            buttonPerform.Name = "buttonPerform";
            buttonPerform.Size = new Size(94, 29);
            buttonPerform.TabIndex = 6;
            buttonPerform.Text = "Виконати";
            buttonPerform.UseVisualStyleBackColor = true;
            buttonPerform.Click += buttonPerform_Click;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Location = new Point(11, 150);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(393, 24);
            radioButton4.TabIndex = 5;
            radioButton4.TabStop = true;
            radioButton4.Text = "Впорядкувати вихідну інформацію за датою дзвінка";
            radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(11, 120);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(408, 24);
            radioButton3.TabIndex = 4;
            radioButton3.TabStop = true;
            radioButton3.Text = "Вивести відомості про останню заявку минулого року";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(11, 90);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(429, 24);
            radioButton2.TabIndex = 3;
            radioButton2.TabStop = true;
            radioButton2.Text = "Підрахувати кількість заявок, поданих в минулому місяці";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(11, 40);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(302, 44);
            radioButton1.TabIndex = 2;
            radioButton1.TabStop = true;
            radioButton1.Text = "Вивести відомості про всі не виконані \r\nзаявки, які надійшли за останні три дні";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // CallsDGV1
            // 
            CallsDGV1.AllowUserToAddRows = false;
            CallsDGV1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            CallsDGV1.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2, dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4, dataGridViewTextBoxColumn5, dataGridViewTextBoxColumn6, dataGridViewTextBoxColumn7 });
            CallsDGV1.Location = new Point(11, 304);
            CallsDGV1.Name = "CallsDGV1";
            CallsDGV1.RowHeadersWidth = 51;
            CallsDGV1.Size = new Size(1240, 346);
            CallsDGV1.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            dataGridViewTextBoxColumn1.HeaderText = "#";
            dataGridViewTextBoxColumn1.MinimumWidth = 6;
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            dataGridViewTextBoxColumn1.Width = 50;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.FillWeight = 48.3871F;
            dataGridViewTextBoxColumn2.HeaderText = "Дата дзвінка";
            dataGridViewTextBoxColumn2.MinimumWidth = 6;
            dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            dataGridViewTextBoxColumn2.Width = 120;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewTextBoxColumn3.HeaderText = "День неділі";
            dataGridViewTextBoxColumn3.MinimumWidth = 6;
            dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            dataGridViewTextBoxColumn3.Width = 75;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewTextBoxColumn4.FillWeight = 306.4516F;
            dataGridViewTextBoxColumn4.HeaderText = "Час дзвінка";
            dataGridViewTextBoxColumn4.MinimumWidth = 6;
            dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewTextBoxColumn5.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn5.FillWeight = 48.3871F;
            dataGridViewTextBoxColumn5.HeaderText = "Адреса абонента";
            dataGridViewTextBoxColumn5.MinimumWidth = 6;
            dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewTextBoxColumn6.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn6.FillWeight = 48.3871F;
            dataGridViewTextBoxColumn6.HeaderText = "Характер несправності";
            dataGridViewTextBoxColumn6.MinimumWidth = 6;
            dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewTextBoxColumn7.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn7.FillWeight = 48.3871F;
            dataGridViewTextBoxColumn7.HeaderText = "Стан заявки";
            dataGridViewTextBoxColumn7.MinimumWidth = 6;
            dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1266, 690);
            Controls.Add(tabControl1);
            Name = "Form2";
            Text = "Form2";
            FormClosed += Form2_FormClosed;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)CallsDGV).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)CallsDGV1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private DataGridView CallsDGV;
        private TabPage tabPage2;
        private DataGridViewTextBoxColumn ColumnNum;
        private DataGridViewTextBoxColumn ColumnDate;
        private DataGridViewTextBoxColumn ColumnDay;
        private DataGridViewTextBoxColumn ColumnTime;
        private DataGridViewTextBoxColumn ColumnAddress;
        private DataGridViewTextBoxColumn ColumnProblem;
        private DataGridViewTextBoxColumn ColumnStatus;
        private Label label2;
        private Label label1;
        private MonthCalendar monthCalendar;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Button buttonDelete;
        private Button buttonEdit;
        private Button buttonAdd;
        private ComboBox comboBoxStatus;
        private TextBox textBoxProblem;
        private TextBox textBoxAddress;
        private TextBox textBoxTime;
        private Button buttonLoad;
        private Button buttonClear;
        private Button buttonSave;
        private Label label7;
        private Button buttonPerform;
        private RadioButton radioButton4;
        private RadioButton radioButton3;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private DataGridView CallsDGV1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private TextBox textBoxCount;
    }
}